"""Variable layouts for conspicuously unofficial fictional study documents."""

import random

from document_generator import Canvas, DISCLAIMER_HEIGHT, INK, MUTED, RED, SIZES, fee_rows, money


def render_variant(kind, profile, data, assets, seed):
    rng = random.Random(str(seed) + kind)
    c = Canvas(SIZES[kind])
    w, h = c.image.size
    margin = rng.randrange(64, 96)
    width = w - 2 * margin
    variant = rng.randrange(3)
    accent = rng.choice([RED, "#27564B", "#414148"])
    title = {"schedule": "Course Schedule", "receipt": "Tuition Estimate", "student_card": "Student Card"}[kind]
    c.text("INDEPENDENT DESIGN PROTOTYPE / UMGC", (margin, 34, width, 40), 22, RED, True)
    if variant == 0:
        c.box((margin, 91, margin + 8, 233), accent)
        c.text(title, (margin + 30, 94, width - 30, 74), rng.randrange(46, 57), INK, True)
        c.text("University of Maryland Global Campus", (margin + 30, 186, width - 30, 44), 26)
    else:
        c.text("University of Maryland Global Campus", (margin, 97, width, 44), 27, INK, True)
        c.text(title, (margin, 161, width, 76), rng.randrange(43, 55), INK, True,
               "right" if variant == 2 else "left")
        c.box((margin, 256, w - margin, 259), accent)
    session = data["session"]
    c.text(session["term"] + " / " + session["name"], (margin, 280, width, 42), 24, MUTED)
    c.text(f"{session['start']} to {session['end']}", (margin, 331, width, 42), 24)
    y = 400 + rng.randrange(0, 22)
    if kind == "student_card":
        portrait_right = variant != 0
        px = w - margin - 320 if portrait_right else margin
        tx = margin if portrait_right else margin + 360
        tw = width - 370
        c.image_at(assets["portrait"], (px, y, 320, 335))
        c.text("FICTIONAL PERSON", (px, y + 355, 320, 40), 20, RED, True)
        c.label("Fictional student", profile["full_name"], tx, y, tw)
        c.label("Prototype ID", profile["student_id"], tx, y + 128, tw)
        c.text(profile["country"] + " / Born " + profile["date_of_birth"], (tx, y + 260, tw, 80), 25)
        c.text("PROTOTYPE VALIDITY: " + session["start"] + " to " + session["end"],
               (margin, 834, width, 50), 27, INK, True)
    else:
        if variant == 1:
            c.label("Prototype ID", profile["student_id"], margin, y, int(width * .40))
            c.label("Fictional student", profile["full_name"], margin + int(width * .43), y, int(width * .57))
        else:
            c.label("Fictional student", profile["full_name"], margin, y, int(width * .60))
            c.label("Prototype ID", profile["student_id"], margin + int(width * .65), y, int(width * .35))
        y += 148
        if kind == "schedule":
            c.text("PROPOSED WEEKLY TIME BLOCKS / NOT A REGISTRATION RECORD", (margin, y, width, 40), 23, RED, True)
            y += 61
            slots = [
                ("Monday and Wednesday", "10:00 AM", "11:15 AM"),
                ("Tuesday and Thursday", "1:00 PM", "2:15 PM"),
                ("Monday", "6:00 PM", "8:30 PM"),
                ("Wednesday", "3:00 PM", "5:30 PM"),
            ]
            for index, course in enumerate(data["courses"]):
                days, start, end = slots[(index + variant) % len(slots)]
                c.box((margin, y, w - margin, y + 2), "#A5A5A5")
                if variant == 2:
                    c.text(course["code"] + " / " + course["title"], (margin, y + 17, width, 66), 28, INK, True)
                    c.text(f"{days}  |  {start} - {end}", (margin, y + 84, width, 40), 23, INK, True)
                    c.text(f"{course['credits']} credits / Online session / Proposed time block",
                           (margin, y + 127, width, 40), 22, MUTED)
                else:
                    c.text(course["code"], (margin, y + 20, 210, 66), 27, INK, True)
                    c.text(course["title"], (margin + 230, y + 20, width - 470, 76), 27)
                    c.text(f"{course['credits']} credits\n{days}", (w - margin - 205, y + 20, 205, 80), 22)
                    c.text(f"{start} - {end} / Online", (margin + 230, y + 92, width - 470, 40), 22, MUTED)
                y += 175
            c.text("Time blocks are fictional planning data. Actual section times and availability have not been verified.",
                   (margin, 941, width, 64), 22, MUTED)
        else:
            c.text("FICTIONAL COST ESTIMATE / NO PAYMENT RECORDED", (margin, y, width, 60), 25, RED, True)
            y += 94
            rows, total = fee_rows(data)
            for row in rows:
                c.box((margin, y, w - margin, y + 2), "#A5A5A5")
                c.text(row["description"], (margin, y + 24, int(width * .63), 64), 29, INK, True)
                c.text(money(row["amount"]) if row["amount"] is not None else "",
                       (margin + int(width * .68), y + 24, int(width * .32), 60), 30, INK, True, "right")
                c.text(f"{row['credits']} credits x {money(row['rate'])}" if row["rate"] is not None else "Rate unavailable",
                       (margin, y + 99, width, 50), 25, MUTED)
                y += 193 if variant == 0 else 174
            c.box((margin, y + 12, w - margin, y + 16), accent)
            c.text("ESTIMATED TOTAL (USD)", (margin, y + 51, int(width * .64), 64), 28, INK, True)
            c.text(money(total) if total is not None else "", (margin + int(width * .68), y + 46, int(width * .32), 72), 36, INK, True, "right")
            c.text("Out-of-state undergraduate rate. No payment or balance settlement is represented.",
                   (margin, 1320, width, 95), 25, RED, True)
            c.text("Public rates checked " + data["verified_on"] + ". Other fees and discounts are not included.",
                   (margin, 1447, width, 90), 23, MUTED)
    c.disclaimer(kind, h - DISCLAIMER_HEIGHT)
    return c
